"Skeleton of the FRM model"
import yaml
from pathlib import Path

class FRM():
    "Skeleton class"

    def __init__(self, config_file=None):

        file_path = Path(__file__)
        config_path = file_path.parents[0] / Path('config.yaml')
        with config_path.open('r') as fobj:
            _config = yaml.safe_load(fobj)

        self.PREP_TIME = _config['PREP_TIME']
        self.LOOSE_TRAILER = _config['PPH_OFFLOAD']['LOOSE_TRAILER']
        self.PIECE_PER_BAG = _config['UNIT_CONVERTION']['PIECE_PER_BAG']
        self.PARCEL_PER_CAGE_DG = _config['UNIT_CONVERTION']['PARCEL_PER_CAGE_DG']
        self.PARCEL_PER_CAGE_NCY = _config['UNIT_CONVERTION']['PARCEL_PER_CAGE_NCY']
        self.HPC = _config['UNIT_CONVERTION']['HPC']

    def input(self):
        "Method to get inputs"
        pass

    def process(self):
        "Method to caculate FRM result"
        pass

    def output(self):
        "Method to persist/show the caculation result."
        pass

    def execute(self):
        "Method to execute whole FRM task"
        self.input()
        self.process()
        self.output()
