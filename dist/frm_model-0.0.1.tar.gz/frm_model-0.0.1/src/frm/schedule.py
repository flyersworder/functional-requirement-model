import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

# define the operational parameters
prep_time = 5 # unit: minutes
pph_offload = {'Loose Trailer': 835} # piece per hour
unit_conversion = {'piece per bag': 27, 'parcel per cage dg': 16, 'parcel per cage ncy': 16, 'hpc': 5}

# define the schedule folder
sch_folder = Path.cwd() / 'Documents/FRM/schedules'
sheet_sch = 'Movement Schedules'

# read all the schedules in this folder and save them as a list
file_path = []
for f in sch_folder.glob('*.xlsx'):
    print(f.name) 
    file_path.append(f)

# import inbound and outbound schedule into different dataframes
inbound = pd.read_excel(file_path[0], sheet_name=sheet_sch, header=1, usecols='A:P', skiprows=[0], parse_dates=[4], keep_default_na=False)
inbound = inbound[inbound.iloc[:, 0] != '']


outbound = pd.read_excel(file_path[0], sheet_name=sheet_sch, header=1, usecols='AI:AX', skiprows=[0], parse_dates=[4], keep_default_na=False)
outbound = outbound[outbound.iloc[:, 0] != '']

# clean up columns names
column_names = []
for name in list(inbound.columns) + list(outbound.columns):
    if (name.find('\\') > 0) | (name.find('(') > 0) | (name.find('.') > 0): 
        name = name[:name.find('\\')]
        name = name[:name.find('(')]
        name = name[:name.find('.')]
    name = name.strip().lower()
    column_names.append(name)

inbound.columns = column_names[:len(inbound.columns)]
outbound.columns = column_names[len(inbound.columns):]

# adjust the arrival/departure time according to the ops day
inbound.loc[inbound['ops day'] == 2,'arrival time'] = inbound['arrival time'] + pd.Timedelta(days=1)
outbound.loc[outbound['ops day'] == 2,'arrival time'] = outbound['departure time'] + pd.Timedelta(days=1)

# calculate offloading/uploading time: arrival/departure time + prepared time
inbound['offload time'] = inbound['arrival time'] + pd.Timedelta(minutes=5)
outbound['onload time'] = outbound['departure time'] + pd.Timedelta(minutes=5)

# calculate inbound/outbound volumes per hour
involume_hour = inbound[['volumes', 'offload time']].resample('1H', on='offload time').sum()
outvolume_hour = outbound[['volumes', 'onload time']].resample('1H', on='onload time').sum()

volume_hour = pd.concat([involume_hour, outvolume_hour], axis=1, sort=False).fillna(0)
volume_hour.columns = ['in', 'out']
volume_hour.index.name = 'time'

# create the grouped chart for in/out volumes per hour
barchart = volume_hour.plot(kind='bar')

plt.tight_layout()
plt.show()

# create the chart to see simultaneously arrival/departure per hour
origin_hour = inbound.groupby('origin').resample('1H', on='arrival time').size()
origin_hour = origin_hour[origin_hour!=0]
origin_hour.sort_values(ascending=False, inplace=True)

dest_hour = outbound.groupby('destination').resample('1H', on='departure time').size()
dest_hour = dest_hour[dest_hour!=0]
dest_hour.sort_values(ascending=False, inplace=True)