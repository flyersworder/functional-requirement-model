import pandas as pd

def volume_availability(inbound, outbound, unit_conversion, pph_offload):

    # unitize inbound pieces
    inbound['coy units'] = inbound['volumes'] * (inbound['box'] + (inbound['documents & smalls'] + inbound['smalls'])/unit_conversion['piece per bag'])
    inbound['ncy units'] = inbound['volumes'] * (inbound['dangerous goods']/unit_conversion['parcel per cage dg']  \
        + inbound['ncoy-uglily']/unit_conversion['parcel per cage ncy'] + inbound['hpc']/unit_conversion['hpc'] + inbound['freight']) 
    
    # separate the data into coy and ncy
    volume_coy = inbound.loc[inbound['coy units']!=0].drop(columns=['ncy units', 'finished offload ncy'])
    volume_ncy = inbound.loc[inbound['ncy units']!=0].drop(columns=['coy units', 'finished offload coy'])

    # calculate offloading time and finished offloading time for different material types
    load_type_coy = volume_coy['load type'].unique()[0]
    load_type_ncy = volume_ncy['load type'].unique()[0]
    volume_coy['finished offload'] = (volume_coy['offload time'] + pd.to_timedelta(volume_coy['coy units']/(pph_offload[load_type_coy]/60), unit='minute')).astype('datetime64[s]')
    volume_ncy['finished offload'] = (volume_ncy['offload time'] + pd.to_timedelta(volume_ncy['ncy units']/(pph_offload[load_type_ncy]/60), unit='minute')).astype('datetime64[s]')

    # calculate ceiling/floor of the processing time
    start_time = (min(inbound['offload time'])).floor('15min')
    end_time = max(max(volume_coy['finished offload']).ceil('15min'), max(volume_ncy['finished offload']).ceil('15min'))
 
    # generate the whole availability array
    t_index = pd.date_range(start=start_time, end=end_time, freq='15T')
    for col in list(t_index): 
        volume_coy[col] = 0
        volume_ncy[col] = 0

    # define the function to calculate the spread per movement
    def volume_spread(movement):
        start_time = movement['offload time'].floor('15min')
        end_time = movement['finished offload'].floor('15min')
        vehicle = movement['load type']
        for time in pd.date_range(start=start_time, end=end_time, freq='15T'):
            if time == start_time:
                movement[time] = (time + pd.Timedelta(minutes=15) - movement['offload time']).seconds/60 * (pph_offload[vehicle]/60)
            elif time == end_time:
                movement[time] = (movement['finished offload'] - time).seconds/60 * (pph_offload[vehicle]/60)
            else: 
                movement[time] = pph_offload[vehicle]/4
        return movement

    # calculate volume spread per movement
    volume_coy = volume_coy.apply(volume_spread, axis=1, result_type='broadcast')
    volume_ncy = volume_ncy.apply(volume_spread, axis=1, result_type='broadcast')